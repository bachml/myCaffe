cp *.cpp ../src/caffe/layers
cp *.cu ../src/caffe/layers
cp *.hpp ../include/caffe/layers
